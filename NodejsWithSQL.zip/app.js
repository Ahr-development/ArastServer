
require('dotenv').config();
const express = require('express')
const app = express();
const cors = require("cors");
const expressLayout = require('express-ejs-layouts') // Support Your App From < ejs >
var path = require('path');
const authService = require("./services/authenticate.service");
const cookieParser = require('cookie-parser');



const port = 5000 || process.env.PORT

app.use(express.json()); 
app.use(cookieParser());
app.use(express.urlencoded({ extended: true })); 
app.use(expressLayout)
app.use(cors())
app.set('layout','./layouts/main');
app.set('view engine' , 'ejs');

app.use(express.static(path.resolve('./public')));





app.use("/", require("./controllers/main.controller"));
app.use("/person", require("./controllers/person.controller"));
app.use("/category", require("./controllers/category.controller"));
app.use("/asset", require("./controllers/asset.controller"));
app.use("/api/asset", require("./controllers/api/assetsApi.controller"));



app.listen(port, () => console.log("Server listening on port " + port));



