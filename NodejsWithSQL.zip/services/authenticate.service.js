
const db = require("../config/db");
const userService = require("../services/users.service");

const getAll = async () => {
  return await db.Authenticates.findAll();
};

const createAuthenticates = async (UserId, AuthenticateCode, BrowserName, AuthDate, RoleId, IsValid, AuthCodeServer) => {
  const newAuthenticates = await db.Authenticates.create({
    UserId,
    AuthenticateCode,
    BrowserName,
    AuthDate,
    RoleId,
    IsValid, // Set IsValid value explicitly
    AuthCodeServer, // Set AuthCodeServer value explicitly
  });

  return newAuthenticates;
};



const findPersonByAuthCode = async (authCode) => {
  const userLogin = await db.Authenticates.findOne({
    where: {
      AuthCodeServer: authCode,
    },
  });

  const user = await userService.findUserById(userLogin.UserId)

  if (userLogin && userLogin.IsValid == true && user != null && user.RoleId == 1 || user.RoleId == 2) {
    return userLogin;

  } else {
    return null;
  }
};




module.exports = {
  getAll,
  createAuthenticates,
  findPersonByAuthCode
};