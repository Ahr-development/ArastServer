/* 


const Sequelize = require('sequelize');

const database = new Sequelize('khorshi6_KhorshidiDB', 'khorshi6_amirhossinrayegan', 'ni$2t6C12', {
  host: '185.252.29.60',
  port: 2022, // Define port separately
  dialect: 'mssql'
});

(async () => {
  try {
    await database.authenticate();
    console.log('Connection to database successful!');
  } catch (error) {
    console.error('Failed to connect to database:', error);
  }
})();

module.exports = database;
*/





const { Sequelize } = require("sequelize");
const personModel = require("../models/person.model");
const userModel = require("../models/users.model");
const authenticatesModel = require("../models/authenticates.model");
const assetsCategory = require("../models/assetsCategory.model");
const assetSubCategory = require("../models/assetSubCategory.model");
const assets = require("../models/assets.model");
const fonts = require("../models/font.model");


require("dotenv").config();

const sequelize = new Sequelize(
  process.env.DB,
  process.env.USER,
  process.env.PASSWORD,
  {
    host: process.env.HOST,
    port: process.env.SQL_PORT,
    dialect: process.env.DIALECT,
    dialectOptions: {
      options: { encrypt: false },
    },
  }
);


const db = {};
db.Person = personModel(sequelize);
db.Users = userModel(sequelize);
db.Authenticates = authenticatesModel(sequelize);
db.AssetsCategory = assetsCategory(sequelize);
db.AssetSubCategory = assetSubCategory(sequelize);
db.Assets = assets(sequelize);
db.Fonts = fonts(sequelize)


// sync all models with database
sequelize.sync({ alter: true });

module.exports = db;