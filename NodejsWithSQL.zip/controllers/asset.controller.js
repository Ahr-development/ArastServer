

const express = require("express");
const router = express.Router();
const userService = require("../services/users.service");
const authService = require("../services/authenticate.service");

const jwt = require('jsonwebtoken');
const jwtSecret = process.env.JWT_SECRET;

const adminLayout = "../views/layouts/adminLayout"
const mainLayout = "../views/layouts/mainLayout"
const simpleLayout = "../views/layouts/simpleLayout"

const assetCategory = require("../services/assetCategory.service")
const assetService = require("../services/assets.service")

const { S3Client, PutObjectCommand, GetObjectCommand } = require("@aws-sdk/client-s3");
const multer = require('multer');
const fs = require('fs');
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");

function generateRandomString(length = 6) {
  const chars = '0123456789'; // Possible characters for the string
  let randomString = '';

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * chars.length);
    randomString += chars[randomIndex];
  }

  return randomString;
}

// Configure multer for temporary file storage
const upload = multer({ dest: 'uploads/' });


const client = new S3Client({
  region: "default",
  endpoint: process.env.ARAST_ENDPOINT,
  credentials: {
    accessKeyId: process.env.ARAST_ACCESS_KEY,
    secretAccessKey: process.env.ARAST_SECRET_KEY
  },
});


function generateUniqueFilename() {
  // Generate a random string of characters
  const randomString = Math.random().toString(36).substring(2, 8);
  // Generate a timestamp to ensure uniqueness
  const timestamp = Date.now().toString(36);
  // Combine random string and timestamp to create unique filename
  return `${randomString}_${timestamp}`;
}


const authMiddleware = async (req, res, next) => {
  const token = req.cookies && req.cookies['arast-panel-token'];
  console.log(token);

  if (!token) {
    return res.redirect("/Login")
  }
  else {
    try {
      const decoded = jwt.verify(token, jwtSecret);
      const auth = await authService.findPersonByAuthCode(decoded.serverCode)
      if (auth != null) {
        next();
      }
      else {
        return res.redirect("/Login")
      }

    } catch (error) {
      return res.redirect("/Login")
    }
  }
}



//Main Admin
router.get('/', authMiddleware, async (req, res) => {
  try {
    const category = await assetCategory.getAllCategories()

    const local = {
      title: "ADMIN",
      description: "توضحیات",
      isAuthorized: false
    }
    await res.render('admin/assets/assets', { local, category, layout: adminLayout })
  } catch (error) {

  }

})





//Main Admin
router.get('/UploadAsset/:categoryId/:assetId', authMiddleware, async (req, res) => {
  try {
    const local = {
      title: "ADMIN",
      description: "توضحیات",
      isAuthorized: false,
      categoryID: req.params.categoryId,
      assetId: req.params.assetId
    }
    await res.render('admin/assets/uploadAsset', { local, layout: simpleLayout })
  } catch (error) {

  }

})





router.get('/getFileAssetsByCategoryId/:id', authMiddleware, async (req, res) => {
  const assets = await assetService.getAllAssetsByCategoryId(req.params.id)

  try {
    const local = {
      title: "ADMIN",
      description: "توضحیات",
      isAuthorized: false
    }


    // برگرداندن لیست زیر دسته ها به صورت JSON
    return res.json(assets);
  } catch (error) {
    console.log(error);
  }

})







router.get('/getAssetInfo/:id', authMiddleware, async (req, res) => {

  try {
    const assets = await assetService.findAssetById(req.params.id)
    let assetLink;

    const params = {
      Bucket: process.env.ARAST_BUCKET_NAME,
      Key: assets.AssetsFileName,
    };

    const command = new GetObjectCommand(params);
    await getSignedUrl(client, command).then((url) => {
      assetLink = url;
    });

    const local = {
      title: "ADMIN",
      description: "توضحیات",
      assets,
      assetLink
    }


    // برگرداندن لیست زیر دسته ها به صورت JSON
    await res.render('admin/assets/assetInfo', { local, layout: simpleLayout })
  } catch (error) {
    console.log(error);
  }

})



router.post('/UploadAsset', authMiddleware, upload.fields([{ name: 'staticFile' }, { name: 'MainFile' }]), async (req, res) => {
  try {
    // Check if req.files is defined and contains the expected files
    if (!req.files || !req.files.staticFile || !req.files.MainFile) {
      return res.status(400).send('No file uploaded');
    }

    const staticFile = req.files.staticFile[0]; // Access the first file in staticFile array
    const mainFile = req.files.MainFile[0]; // Access the first file in MainFile array

    const STATIC_BUFFER = fs.readFileSync(staticFile.path);
    const MAIN_BUFFER = fs.readFileSync(mainFile.path);

    const newStaticFilename = `Assets/${generateUniqueFilename()}_${staticFile.originalname}`;
    const newMainFilename = `ArastAssets/${generateUniqueFilename()}_${mainFile.originalname}`;


    const paramsForStatic = {
      Bucket: process.env.ARAST_STATIC_BUCKET_NAME,
      Key: newStaticFilename,
      Body: STATIC_BUFFER
    };

    const paramsForMain = {
      Bucket: 'arastme',
      Key: newMainFilename,
      Body: MAIN_BUFFER
    };

    // Assuming "client" is your S3 client

    // Upload mainFile
    client.send(new PutObjectCommand(paramsForMain), (error, data) => {
      if (error) {
        console.log(error);
      } else {
        console.log(data);
      }
    });

    // Upload staticFile
    client.send(new PutObjectCommand(paramsForStatic), (error, data) => {
      if (error) {
        console.log(error);
      } else {
        console.log(data);
      }
    });

    // Get signed URL for staticFile
    const staticCommand = new GetObjectCommand(paramsForStatic);
    let staticAssetLink;
    await getSignedUrl(client, staticCommand).then((url) => {
      staticAssetLink = url;
    });

    const data = {
      TypeId: 1,
      CategoryId: req.body.CategoryId,
      StoreId: 1,
      PersianName: req.body.PersianName,
      EnglishName: req.body.EnglishName,
      ArabicName: req.body.ArabicName,
      Description: req.body.Description,
      PriceIRR: req.body.PriceIRR,
      PriceUSD: req.body.PriceUSD,
      UsingNumber: 0,
      StarCounter: 0,
      ColorUsing: req.body.ColorUsing,
      AssetsFileName: newMainFilename,
      AssetsAddress: null,
      AssetsStaticFile: newStaticFilename,

    };

    // Assuming "assetService" handles asset creation
    await assetService.createAsset(data);

    // Delete the temporary files
    await fs.promises.unlink(staticFile.path);
    await fs.promises.unlink(mainFile.path);

    return res.redirect("/asset");
  } catch (error) {
    console.error(error);
    res.status(500).send('Error uploading file to S3');
  }
});






module.exports = router;

// route functions
