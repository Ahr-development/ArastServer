
const db = require("../config/db");


const createAsset = async (data) => {
    try {
      const newAsset = await db.Assets.create(data);
      return newAsset;
    } catch (error) {
      console.error('Error creating asset:', error.message);
      throw error; // Re-throw the error for handling at a higher level
    }
  };
  

  const getAllAssetsByCategoryId = async (categoryId) => {
    const assets = await db.Assets.findAll({
      where: { CategoryId: categoryId },
    });
    return assets;
  };
  


  const getAssetsApi = async (count) => {
    const assets = await db.Assets.findAll({
      order: [['Id', 'ASC']],
      offset: (count - 1) * 30,
      limit: 30,
    });
    return assets;
  };
  


  const findAssetById = async (id) => {
    return await db.Assets.findByPk(id);
  };
  





  

  
module.exports = {
    createAsset,
    getAllAssetsByCategoryId,
    findAssetById,
    getAssetsApi
  };