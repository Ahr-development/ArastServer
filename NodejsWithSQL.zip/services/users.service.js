


const db = require("../config/db");

const getAll = async () => {
  return await db.Users.findAll();
};

const findUserById = async (id) => {
  return await db.Users.findByPk(id);
};


const findUserByPhoneAndPassword = async (Mobile, Password) => {
  
    // 1. Query the User table using phoneNumber and hashedPassword
    const user = await db.Users.findOne({
      where: {
        Mobile,
        Password,
      },
    });
  
    // 3. Return the user if found, otherwise null
    if (user) {
      return user;
    } else {
      return null;
    }
  };
  

const deleteUser = async (Id) => {
  await db.Users.destroy({
    where: { Id: Id },
  });
};

module.exports = {
  getAll,
  findUserById,
  findUserByPhoneAndPassword,
  deleteUser,
};