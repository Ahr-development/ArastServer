
const express = require("express");
const router = express.Router();
const adminLayout = "../../views/layouts/adminLayout"
const simpleLayout = "../../views/layouts/simpleLayout"

const authService = require("../../services/authenticate.service");
const assetService = require("../../services/assets.service")



// Controller function to fetch data based on count parameter
router.get('/getAssetsByArastApi/:count', async (req, res) => {
    const count = parseInt(req.params.count); // Get the count parameter
  
    try {
      // Fetch 30 users starting from the specified offset (count * 30)
       const assets = await assetService.getAssetsApi(count)

      // Send the retrieved users as JSON response
      res.json(assets);
    } catch (error) {
      console.error(error);
      res.status(500).send('Error fetching users');
    }
  });
  















module.exports = router;
