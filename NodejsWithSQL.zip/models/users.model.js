const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Users = sequelize.define('Users', {
    Id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
    },
    ActiveCode: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    RoleId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    FirstName: {
      type: DataTypes.STRING(255), // Adjust max length as needed
      allowNull: false,
    },
    LastName: {
      type: DataTypes.STRING(255), // Adjust max length as needed
      allowNull: false,
    },
    Password: {
      type: DataTypes.STRING(255), // Adjust max length as needed
      allowNull: false,
    },
    Mobile: {
      type: DataTypes.STRING(255), // Adjust max length as needed
      allowNull: false,
    },
    IsActivateNumber: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
    },
  }, {
    // Prevent Sequelize from pluralizing the table name (optional)
    freezeTableName: true,
    // Disable automatic timestamps (optional)
    timestamps: false,
  });


  return Users;
};
